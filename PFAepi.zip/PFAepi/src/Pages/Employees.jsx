import React from 'react';
import { GridComponent, ColumnsDirective, ColumnDirective,Page, Search, Inject, Toolbar } from '@syncfusion/ej2-react-grids';
import { Button, Label, Card, CardTitle, CardBody, Row, InputGroup,
  InputGroupAddon,Input ,Modal,
  ModalHeader,
  ModalBody,
  ModalFooter, Table, CustomInput} from "reactstrap";
import {employeesData, employeesGrid } from '../Data/dummy';
import {Header} from '../Components'
import { NavLink } from 'react-router-dom'
const Employees = () => {
  return (
    <div className="m-2 md:m-10 mt-24 p-2 md:p-10 bg-white rounded-3xl">
      <Header title="Eléves" />
      <NavLink to="/Ajouter" ><Button variant="danger" size="md" block="block" type="submit">
          Ajouter
        </Button></NavLink>
      <GridComponent
        dataSource={employeesData}
        allowPaging
        allowSorting
        toolbar={['Search']}
        width= 'auto'
      >
        <ColumnsDirective>
          {employeesGrid.map((item, index) => <ColumnDirective key={index} {...item} />)}
        </ColumnsDirective>
        <Inject services={[Page, Search, Toolbar]} />
      </GridComponent>
    </div>
  );
};
export default Employees;