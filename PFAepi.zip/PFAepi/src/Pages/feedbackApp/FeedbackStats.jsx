import React from 'react'

export const FeedbackStats = () => {
  return (
    <div>
         <div className='feedback-stats'>
                    <h4>Feedbacks : 5</h4>
                    <h4>average : 5.75</h4>
                </div>
    </div>
  )
}
