import React from 'react';
import Form from 'react-bootstrap/Form'
import { Button, Label, Card, CardTitle, CardBody, Row, InputGroup,
  InputGroupAddon,Input ,Modal,
  ModalHeader,
  ModalBody,
  ModalFooter, Table, CustomInput} from "reactstrap";
const AjouterEleve = () => {
    return (
      <div className="form-wrapper">
      <Form onSubmit={this.onSubmit}>
      <Form.Group>
                  <Label htmlFor="imgAsso">Logo Association</Label>
                  <Input type="file" id="imgAsso"
                         onChange={this.fileChangeHandler}/>
                  {
                    this.state.erreur===false ?
                      <Form.Text>{this.state.fileErr}</Form.Text>:null
                  }
                  {
                    this.state.erreur===true ?
                      <Form.Text id ="colorEr" className="help-block">{this.state.fileErr}</Form.Text>:null
                  }
                </Form.Group>
        <Form.Group controlId="Name">
          <Form.Label>Nom</Form.Label>
          <Form.Control type="text" value={this.state.title} onChange={this.onChangeStudentTitle} />
        </Form.Group>

        <Form.Group controlId="Email">
          <Form.Label>Ville</Form.Label>
          <Form.Control type="text" value={this.state.Ville} onChange={this.onChangeStudentVille} />
        </Form.Group>

        <Form.Group controlId="Name">
          <Form.Label>Tel</Form.Label>
          <Form.Control type="text" value={this.state.Tel} onChange={this.onChangeStudentTel} />
        </Form.Group>

        <Button variant="danger" size="lg" block="block" type="submit">
          Create Association
        </Button>
      </Form>
    </div>
    )
}

export default AjouterEleve