import React from 'react'

const Header = () => {
  return (
    <div>
       <header id='header'>
        <div className='intro'>
            <div className='container'>
              <div className='row'>
                <div className='col-md-8 col-md-offset-2 intro-text'>
                   <nav className="navbar navbar-expand-md">
            <ol className="navbar-nav menu">
                <ol className="nav-item">
                     <a className="nav-link lismenu" active href="/#">Acceuil</a>
                 </ol>
                 <ol className="nav-item">
                    <a className="nav-link lismenu" href="/#">Associations</a>
                </ol>
                <ol className="nav-item">
                    <a className="nav-link lismenu" href="/#">Bénévoles</a>
                </ol>
                <ol className="nav-item">
                    <a className="nav-link lismenu" href="/#">Contact</a>
                </ol>
            </ol>
        </nav>
                  <h3>
                    MADRASTI devient mon école
                <h3>Avec beaucoup plus de nouveautés !</h3>
                    <span></span>
                  </h3>
                  <p>Le logiciel de gestion d'école qui simplifie la vie de ses responsables</p>
                  <a
                    href='#features'
                    className='btn-commence '
                  >
                    Commencer maintenant
                </a>
                </div>
              </div>
            </div>
        
        </div>
       
      </header>
    </div>
  )
}

export default Header
