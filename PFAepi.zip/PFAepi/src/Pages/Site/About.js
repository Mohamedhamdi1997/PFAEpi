import React from 'react'

const About = () => {
  return (
    <div>
      <div id="about">
      <div className="container">
        <div className="row">
          <div className="col-xs-12 col-md-6">
            <img src="../../fontEcole.jpg" className="img-about" alt="benevole" />
          </div>
          <div className="col-xs-12 col-md-6">
            <div className="about-text">
              <h2>Qui sommmes nous ?</h2>
              <p>MADRASTI est une plate-forme de gestion d'école simple et complet qui répond à tous vos besoins, c'est Un logiciel de gestion automatisé qui fait gagner un maximum de temps à votre école.</p>
              <button className="plus">Voir plus</button>
             
              
            </div>  
          </div>
        </div>
      </div>
    </div>

    <div id='services' className='text-center'>
      <div className='container'>
        <div className='section-title'>
          <h3>Un logiciel de gestion d'école simple et complet qui répond à tous vos besoins</h3>
        </div>
        <div className='row'>
             
        </div>
       
      </div>
    </div>
    </div>
  )
}

export default About
