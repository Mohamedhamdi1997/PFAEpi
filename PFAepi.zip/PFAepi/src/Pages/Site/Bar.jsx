import React from 'react'
import { NavLink } from "react-router-dom";
const Bar = () => {
  return (
    <div>
       <nav id='menu' className='navbar navbar-default navbar-fixed-top'>
      <div className='container'>
        <div className='navbar-header'>
          
          <a className='navbar-brand page-scroll' href='#page-top'>
          <img alt="logo" src="../../logoEcole2.png" />
       
          </a><span className="logo">MADRASTI</span>
        </div>

        
     <NavLink to="/user/register"> <button type='submit' className='mb-2 btn-info1'>Inscription</button> </NavLink>
      <NavLink to="/user"> <button type='submit' className='mb-2 btn-info2'>Connexion</button></NavLink>
        </div>
    </nav>
    </div>
  )
}

export default Bar
